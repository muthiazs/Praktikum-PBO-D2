//Nama = Muthia Zhafira Sahnah 
//NIM = 24060122130071 
//Responsi tanggal 27/03/2024

public class QueueOfNumber extends Queue {
    public QueueOfNumber(){

    }

    public boolean cekElmtType(Object elmt){
        return (elmt instanceof Integer);
    }
}
